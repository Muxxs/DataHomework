//
// Created by Muxxs on 2020/10/7.
//

#include <iostream>
#include "student.cpp"

using namespace std;

int main(){
    student S;
    S.set_value();
}