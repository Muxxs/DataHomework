//
// Created by Muxxs on 2020/10/7.
//

#include "rectangle.h"
