//
// Created by Muxxs on 2020/10/7.
//

#include <iostream>
#include "arraymax.cpp"

int main(){
    Array_max array;
    array.set_value();
    array.show_value();
    array.max_value();
    return 0;
}